package utils;

public class MySQLConnection {

    public boolean saveOperation(int v1, int v2)
}
