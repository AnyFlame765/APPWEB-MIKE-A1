package client;

import org.apache.xmlrpc.XmlRpcException;
import org.apache.xmlrpc.client.XmlRpcClient;
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class ClienteRPC {
    private static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) throws MalformedURLException, XmlRpcException {
       String option = "", num1 ="", num2="";

        XmlRpcClientConfigImpl config = new XmlRpcClientConfigImpl();
        config.setServerURL(new URL("http://localhost:1200"));
        XmlRpcClient client = new XmlRpcClient();
        client.setConfig(config);

       do {
           System.out.println("1. Suma");
           System.out.println("2. Resta");
           System.out.println("3. Multiplicacion");
           System.out.println("4. Division");
           System.out.println("5. Exponente");
           System.out.println("6. Raiz");
           System.out.println("7. Salir");
           option = sc.next();

               switch (Integer.parseInt(option)){
                   case 1:
                       System.out.println("--SUMA--");
                       do {
                           System.out.println("Ingresa el primer valor");
                           num1 = sc.next();
                           if (isNumber(num1)){
                               System.out.println("Error, ingrese un valor númerico");
                           }
                       }while (isNumber(num1));

                       do {
                           System.out.println("Ingresa el segundo valor");
                           num2 = sc.next();
                           if (isNumber(num2)){
                               System.out.println("Error, ingrese un valor númerico");
                           }
                       }while (isNumber(num2));

                       //Llamada al servicio web
                       Object[] operation = {num1, num2};
                       int response = (int)
                               client.execute("Methods.suma", operation);
                       System.out.println("La suma es :" + response);
                       break;

                   case 2:
                       System.out.println("--Resta--");
                       System.out.println("Ingrese el primer valor");
                       int v1 = sc.nextInt();
                       System.out.println("Ingrese el segundo valor");
                       int v2 = sc.nextInt();
                       Object[] resta = {v1, v2};
                       int ex = (int)
                               client.execute("Methods.resta", resta);
                       System.out.println("La resta es: " + ex);
                       break;


                   case 3:
                       System.out.println("--Multiplicación--");
                       break;

                   case 4:
                       System.out.println("--Division--");

                       break;

                   case 5:
                       System.out.println("--Potencia--");

                       break;

                   case 6:
                       System.out.println("--Raiz--");
                       break;

                   default:
                       System.out.println("Ingresa una opción válida");
               }
       }while (!option.equals("7"));
    }

    public static boolean isNumber(String number){
        try {
            int num = Integer.parseInt(number);
                    return false;
        }catch (NumberFormatException e){
            return false;
        }

    }
}
