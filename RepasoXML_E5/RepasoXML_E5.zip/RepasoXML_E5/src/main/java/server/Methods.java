package server;

public class Methods {
    public double suma(int v1, int v2){
        return v1 + v2;
    }

    public int resta(int v1, int v2){
        return v1 - v2;
    }

    public int multi(int v1, int v2){
        return v1 * v2;
    }

    public int div(int v1, int v2){
        return v1/v2;
    }

    public double exponente(int v1, int v2){
        return Math.pow(v1, v2);
    }
    public double raiz(int v1, int v2){
        return Math.sqrt(v1);
    }
}
