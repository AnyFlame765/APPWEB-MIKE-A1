package server;

public class Methods {
    public String operation(double v1, double v2, double v3, double v4){
        double producto = v1 * v2 *v3*v4;
        double suma = v1+v2+v3+v4;
        double promedio = (v1+v2+v3+v4)/4;
        String message = "Hola, el producto es: " + producto + "\nLa suma es: " +suma+ "\n El promedio es: " + promedio;
        return message;
    }

    public int suma (int value1, int value2){
        int suma = 0;
        for (int i = value1 ; i < value2; i++ ){
             suma = suma + i;
        }
        return suma;
    }

    public int arrayNumber(){
        int[] array = new int[5];
        for (int i = 0 ; i<array.length; i++){
            System.out.println("Ingresa el valor para " + (i+1));
            
        }
    }
}
